package com.mamun.computerdepartment;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.Window;
import android.view.WindowManager;

public class Jhenaidah_Activity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_jhenaidah_);
		final Animation aniamScale =AnimationUtils.loadAnimation(this,R.anim.anim_scale);
		
		
		findViewById(R.id.button1).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Mamun.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
		 findViewById(R.id.button2).setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View view) {
					Intent intent=new Intent(Jhenaidah_Activity.this,Yead.class);
					startActivity(intent);
					view.startAnimation(aniamScale);
				}
			});
		 findViewById(R.id.button3).setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View view) {
					Intent intent=new Intent(Jhenaidah_Activity.this,Amdadul.class);
					startActivity(intent);
					view.startAnimation(aniamScale);
				}
			});
		 findViewById(R.id.button4).setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View view) {
					Intent intent=new Intent(Jhenaidah_Activity.this,Jahan.class);
					startActivity(intent);
					view.startAnimation(aniamScale);
				}
			});
		 findViewById(R.id.button5).setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View view) {
					Intent intent=new Intent(Jhenaidah_Activity.this,Sabbir.class);
					startActivity(intent);
					view.startAnimation(aniamScale);
				}
			});
     findViewById(R.id.button6).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Rana.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button7).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Sujun.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button8).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Shamim.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button9).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Masud.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button10).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Mahamud.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button11).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Anomika.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button12).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Monir.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button13).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Juwel.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button14).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Bina.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
  
    
     
     findViewById(R.id.button15).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Rina.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button16).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Rabeya.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button18).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Shuvo.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button19).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Antor.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     
     
     
     findViewById(R.id.button20).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Arafat.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     
     findViewById(R.id.button21).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Shribas.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button22).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Tazim.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button23).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Sakib.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button24).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Monaim.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button25).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Noman.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     
     findViewById(R.id.button26).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Fahad.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button27).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Trissna.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button28).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Eti_Biswas.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button29).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Salauddin.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button30).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Sahin.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button31).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Shobuj.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button32).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Towkir.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
  
     
     findViewById(R.id.button33).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Ashraful.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     
     findViewById(R.id.button34).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Shamima.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button35).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Subroto.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     
     
     
     
     
     
     findViewById(R.id.button36).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(Jhenaidah_Activity.this,Shuvagoto.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
     findViewById(R.id.button37).setOnClickListener(new OnClickListener() {
			
  			@Override
  			public void onClick(View view) {
  				Intent intent=new Intent(Jhenaidah_Activity.this,Shobuj_Ahmed.class);
  				startActivity(intent);
  				view.startAnimation(aniamScale);
  			}
  		});
  	}
	
	
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jhenaidah_, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item){
		switch(item.getItemId()){
		case R.id.aboutUs:
			Intent i = new Intent(Jhenaidah_Activity.this, Mamun.class);
			startActivity(i);
			return true;
		case R.id.exit:
			System.exit(0);
			default:
				return super.onOptionsItemSelected(item);
		}
	}

}
