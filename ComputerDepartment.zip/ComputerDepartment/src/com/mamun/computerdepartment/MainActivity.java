package com.mamun.computerdepartment;


import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.FeatureInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		final Context context = this;
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_main);
		final Animation aniamScale =AnimationUtils.loadAnimation(this,R.anim.anim_scale);
		TextView tv = (TextView) this.findViewById(R.id.textView2);  
        tv.setSelected(true); 
		findViewById(R.id.button1).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(MainActivity.this,Dist_Info.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
	findViewById(R.id.button2).setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View view) {
				Intent intent=new Intent(MainActivity.this,Teacher_Info.class);
				startActivity(intent);
				view.startAnimation(aniamScale);
			}
		});
	
	findViewById(R.id.button3).setOnClickListener(new OnClickListener() {
	 
	  @Override
	  public void onClick(View view) {
	    Intent intent = new Intent(context, Website.class);
	    startActivity(intent);
	    view.startAnimation(aniamScale);
	  }

	});
	findViewById(R.id.button4).setOnClickListener(new OnClickListener() {
		 
		  @Override
		  public void onClick(View view) {
		    Intent intent = new Intent(context, Bteb.class);
		    startActivity(intent);
		    view.startAnimation(aniamScale);
		  }

		});
	
	

	
	

}
	
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		createDialog();
	}

	private void createDialog() {
		// TODO Auto-generated method stub
		AlertDialog.Builder alertDlg = new AlertDialog.Builder(this);
		alertDlg.setMessage("Are You Sure Want To Exit?");
		alertDlg.setCancelable(false);
		
		alertDlg.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				MainActivity.super.onBackPressed();
				
				
			}
		});
		alertDlg.setNegativeButton("No", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		});
		
		alertDlg.create().show();
	
	}

	@Override
	protected void onUserLeaveHint() {
		Toast.makeText(MainActivity. this, "Thank You For Visit Our App", Toast.LENGTH_LONG).show();
		super.onUserLeaveHint();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()){
		case R.id.aboutUs:
			Intent i = new Intent(MainActivity.this, Mamun.class);
			startActivity(i);
			return true;
		case R.id.exit:
			System.exit(0);
			default:
		return super.onOptionsItemSelected(item);
		}
	}

}
